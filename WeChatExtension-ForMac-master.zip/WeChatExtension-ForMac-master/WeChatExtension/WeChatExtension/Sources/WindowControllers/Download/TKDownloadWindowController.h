//
//  TKDownloadWindowController.h
//  WeChatExtension
//
//  Created by WeChatExtension on 2018/4/28.
//  Copyright © 2018年 WeChatExtension. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface TKDownloadWindowController : NSWindowController

+ (instancetype)downloadWindowController;

@end
