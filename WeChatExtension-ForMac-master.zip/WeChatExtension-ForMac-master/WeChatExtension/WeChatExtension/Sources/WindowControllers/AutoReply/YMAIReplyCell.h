//
//  YMAIReplyCell.h
//  WeChatExtension
//
//  Created by MustangYM on 2019/12/3.
//  Copyright © 2019 MustangYM. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN
@interface YMAIReplyCell : NSControl
@property (nonatomic, strong) NSString *wxid;
@end

NS_ASSUME_NONNULL_END
