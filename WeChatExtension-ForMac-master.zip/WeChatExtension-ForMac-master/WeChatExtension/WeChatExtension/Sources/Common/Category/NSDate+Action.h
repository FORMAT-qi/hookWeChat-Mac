//
//  NSDate+Action.h
//  WeChatExtension
//
//  Created by WeChatExtension on 2018/7/25.
//  Copyright © 2018年 WeChatExtension. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (Action)

- (BOOL)isToday;
- (BOOL)isYesterday;

@end
