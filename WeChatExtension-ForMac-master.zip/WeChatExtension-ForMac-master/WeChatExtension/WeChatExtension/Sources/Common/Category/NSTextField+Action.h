//
//  NSTextField+Action.h
//  WeChatExtension
//
//  Created by WeChatExtension on 2017/9/19.
//  Copyright © 2017年 WeChatExtension. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSTextField (Action)

+ (instancetype)tk_labelWithString:(NSString *)stringValue;

@end
