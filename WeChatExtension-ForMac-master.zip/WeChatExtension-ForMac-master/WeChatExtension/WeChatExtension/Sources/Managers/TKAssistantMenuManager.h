//
//  TKAssistantMenuManager.h
//  WeChatExtension
//
//  Created by WeChatExtension on 2018/4/24.
//  Copyright © 2018年 WeChatExtension. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TKAssistantMenuManager : NSObject

+ (instancetype)shareManager;
- (void)initAssistantMenuItems;

@end
