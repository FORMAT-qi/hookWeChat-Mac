//
//  WeChat+hook.h
//  WeChatExtension
//
//  Created by WeChatExtension on 2017/4/19.
//  Copyright © 2017年 WeChatExtension. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSObject (WeChatHook)

+ (void)hookWeChat;

@end
