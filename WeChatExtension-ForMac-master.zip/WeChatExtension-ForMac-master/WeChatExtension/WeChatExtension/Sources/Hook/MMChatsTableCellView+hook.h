//
//  MMChatsTableCellView+hook.h
//  WeChatExtension
//
//  Created by WeChatExtension on 2017/9/15.
//  Copyright © 2017年 WeChatExtension. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSObject (MMChatsTableCellViewHook)

+ (void)hookMMChatsTableCellView;

@end
