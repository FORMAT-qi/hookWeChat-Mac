//
//  MMStickerMessageCellView+hook.m
//  WeChatExtension
//
//  Created by WeChatExtension on 2018/2/23.
//  Copyright © 2018年 WeChatExtension. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSObject (MMStickerMessageCellView)

+ (void)hookMMStickerMessageCellView;

@end
