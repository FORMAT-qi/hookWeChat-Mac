---
name: '提Issue注意'
about: 请先阅读Wiki, 并遵循相关Issue规则
title: ''
labels: ''
assignees: ''

---
Issue示例
1. MacOS版本 : 10.xx.x
2. 微信版本 : 2.x.x
3. 小助手版本 : 2.x.x
4. BUG描述 : 会话头像抖动
5. 操作场景 : 微信启动后, 鼠标左键点击会话列表中某个会话的头像
6. 方便的话提供日志, 截图或者视频(可选)
