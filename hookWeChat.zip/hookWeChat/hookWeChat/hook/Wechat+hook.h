//
//  Wechat_hook.h
//  WeChatEX
//
//  Created by 贾仕琪 on 2020/5/8.
//  Copyright © 2020 贾仕琪. All rights reserved.
//

#import <Cocoa/Cocoa.h>




@interface NSObject (WeChatHook)
+ (void)hookWeChat;
@end


